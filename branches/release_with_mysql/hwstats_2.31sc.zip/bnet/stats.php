<tr><td colspan=10>
<table border=0><tbody><tr>
<td><b>StarCraft Ladder</b>&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td align=center>
</td>
</tr></tbody></table>
</td></tr>

		<TR>
                            <TD class=rankingHeader align=middle><A class=button href="">Rank<IMG height=6 src="stats.files/arrow-down.gif" width=14 border=0></A></TD>

                            <TD class=rankingHeader><A class=button href="">Rating</A></TD>
                            <TD class=rankingHeader align=middle><A class=button href="">Stats</A></TD>
                            <TD class=rankingHeader><A class=button href="">Player Name</A></TD>
                            <TD class=rankingHeader align=middle><A class=button href="">Wins</A></TD>
                            <TD class=rankingHeader align=middle><A class=button href="">Losses</A></TD>
                            <TD class=rankingHeader align=middle><A class=button href="">Draws</A></TD>
                            <TD class=rankingHeader><A class=button href="">All Games</A></TD>
                            <TD class=rankingHeader><A class=button href="">Last</A></TD>
                           
			    
<?php
if ($show_player_ip) echo '<TD class=rankingHeader align=middle><A class=button href="">IP adress</A></TD>';

echo "</TR>";

MYSQL_CONNECT($hostname,$username,$password) OR DIE("�� ���� ������� ���������� ");
mysql_select_db($db_bnet) or die("Can not select database");


$limit_time=gmmktime() - 2592000 * 5;
$lim_first = $current_page*$players_on_page-$players_on_page;

// ���� ��������� �������� �� ������, ������� ������ �� ����
if ( $searchPlayer )
{
	if ( strlen($searchPlayer) >= $min_search_symbols )
	{
		$condition = 'LIKE "%' . strtolower(mysql_escape_string($searchPlayer)) . '%"';
		
	/*
		// long search #1
		$result = MYSQL_QUERY("SELECT uid, SEXP_1_last_game_result, SEXP_1_rating, SEXP_1_rank, SEXP_0_wins, SEXP_0_losses,  SEXP_0_disconnects, SEXP_1_wins, SEXP_1_losses, SEXP_0_draws,SEXP_1_draws FROM $table_record 
		WHERE uid IN ( SELECT uid FROM $table_bnet WHERE acct_username $condition ) 
		ORDER BY SEXP_1_rating DESC;");

		// long search #2
		$result = MYSQL_QUERY("SELECT {$table_record}.uid,SEXP_1_last_game_result, SEXP_1_rating, SEXP_1_rank, SEXP_0_wins, SEXP_0_losses,  SEXP_0_disconnects, SEXP_1_wins, SEXP_1_losses, SEXP_0_draws,SEXP_1_draws, 
		{$table_bnet}.acct_username, {$table_bnet}.acct_lastlogin_ip, {$table_bnet}.acct_lastlogin_time
		FROM $table_record  LEFT JOIN $table_bnet
		ON {$table_record}.uid = {$table_bnet}.uid
		WHERE username $condition ORDER BY SEXP_1_rating DESC;");
	*/	
	
		// fast search
		$result = MYSQL_QUERY("SELECT record.uid, record.SEXP_1_last_game_result, record.SEXP_1_rating, record.SEXP_1_rank, record.SEXP_0_wins, record.SEXP_0_losses, record.SEXP_0_disconnects, record.SEXP_1_wins, record.SEXP_1_losses, record.SEXP_0_draws,record.SEXP_1_draws,
		{$table_bnet}.acct_username, {$table_bnet}.acct_lastlogin_ip, {$table_bnet}.acct_lastlogin_time
		FROM $table_bnet
		LEFT JOIN $table_record
		ON {$table_bnet}.uid = {$table_record}.uid
		WHERE username $condition and {$table_record}.SEXP_1_rank > 0;");

	
		$players_count = mysql_num_rows($result);
	}
	else
	{
		echo sprintf("<h3 align=center>Please, input %s or more symbols</h3>", $min_search_symbols);
	}
}
// ����� ������� ���� �������
else
{	
	$result = MYSQL_QUERY("SELECT (select count(*) from $table_record) as count, uid, SEXP_1_last_game_result, SEXP_1_rating, SEXP_1_rank, SEXP_0_wins, SEXP_0_losses,  SEXP_0_disconnects, SEXP_1_wins, SEXP_1_losses, SEXP_0_draws,SEXP_1_draws FROM $table_record 
	ORDER BY SEXP_1_rating DESC LIMIT $lim_first,$players_on_page;");

	$players_count = mysql_result($result,0,"count");
}


// $players_count = mysql_result( mysql_query("SELECT FOUND_ROWS()"),0 );

$number = @MYSQL_NUM_ROWS($result); #����� �������

for ($i=0;$i<$number;$i++)
{
	$p_uid=mysql_result($result,$i,"uid"); #player unicue id
	
	$p_SEXP_1_last_game_result=mysql_result($result,$i,"SEXP_1_last_game_result"); 
	$p_SEXP_1_rating=mysql_result($result,$i,"SEXP_1_rating"); 
	$p_SEXP_1_rank=mysql_result($result,$i,"SEXP_1_rank"); 
	
	#if (!$p_SEXP_1_rank) // display only SEXP players
	#	continue;

	$p_SEXP_0_wins=mysql_result($result,$i,"SEXP_0_wins"); 
	$p_SEXP_0_losses=mysql_result($result,$i,"SEXP_0_losses"); 
	$p_SEXP_0_draws=mysql_result($result,$i,"SEXP_0_draws"); 
	$p_SEXP_1_wins=mysql_result($result,$i,"SEXP_1_wins"); 
	$p_SEXP_1_losses=mysql_result($result,$i,"SEXP_1_losses"); 
	$p_SEXP_1_draws=mysql_result($result,$i,"SEXP_1_draws"); 

	if ($searchPlayer)
	{
		$result2 = $result;
		$j = $i;
	}
	else
	{
		$result2 = MYSQL_QUERY("SELECT acct_username, acct_lastlogin_ip,acct_lastlogin_time FROM $table_bnet WHERE uid='$p_uid' LIMIT 1");
		$j = 0;
	}
	
	$p_acct_username=mysql_result($result2,$j,"acct_username");
	$p_acct_lastlogin_time=mysql_result($result2,$j,"acct_lastlogin_time");
	$p_acct_lastlogin_ip=mysql_result($result2,$j,"acct_lastlogin_ip");

	$allgames=$p_SEXP_0_wins+$p_SEXP_0_losses+$p_SEXP_1_wins+$p_SEXP_1_losses;
	$alldraws=$p_SEXP_0_draws+$p_SEXP_1_draws;

	if ($p_SEXP_1_rank==1): $img1="GOSU";
	elseif ($p_SEXP_1_rank==2): $img1="GOS3";
	elseif ($p_SEXP_1_rank==3): $img1="HAS2";
	elseif ($p_SEXP_1_rank==4): $img1="CHO1";
	else: $img1="NEWB";    
	endif;

	#$pp='<table cellpadding="2" cellspacing="0" width="98%" border="1" bordercolor="white" class="infotable"><tr class="row">';

	 require ("bnet/games/stat.php"); #���� ������� �� �������� � �� �������
	#echo $pp.$txtstat;

}
MYSQL_CLOSE();

	echo "<tr><td colspan=10><small>";
	
	if (!$searchPlayer)
		echo pageNavigator($current_page, $players_on_page, $players_count, $trim_count, "index.php?game=SEXP&type=1&");
	

	echo "</small></td></tr>";



?>

