#!/bin/sh

#CHANGE "full_path_to" TO REAL PATH
/usr/local/bin/php full_path_to/script/parse_reports.php